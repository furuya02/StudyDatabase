            
            <?php do_action('sidebar_right') ?>

            </div> <!-- .row-fluid -->
		
        </div> <!-- #container -->		

		<?php do_action( 'bp_after_container' ) ?>
		
		<?php do_action( 'bp_before_footer' ) ?>
		
		<div id="footer">
			<?php do_action( 'bp_footer' ) ?>
		</div><!-- #footer -->

		<?php do_action( 'bp_after_footer' ) ?>

	</div><!-- #outerrim -->

	<?php wp_footer(); ?>

	</body>

</html>