<?php 
require_once('page-meta-box.php');
require_once('post-meta-box.php');
